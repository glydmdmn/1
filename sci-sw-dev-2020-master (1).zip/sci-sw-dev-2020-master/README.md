# sci-sw-dev-2020
Repository for projects in the PhD course Tools for Scientific Software Development and Data Science
